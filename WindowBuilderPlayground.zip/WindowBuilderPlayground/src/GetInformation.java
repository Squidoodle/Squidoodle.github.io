import java.util.Arrays;
import java.util.Scanner;

public class GetInformation {

	public static void main(String[] args) {
		String[] arrayPlaces = { "Edmonds", "Pier 55", "Redondo Beach", "Dash Point", "Point Defiance", "Waterman" };
		
		Scanner input = new Scanner(System.in); // This should be the only scanner object
		boolean done = false;
		boolean isNumber;
		
		while (!done) {

			System.out.println("                                         Welcome to the Squid Map record!");
			System.out.print("Please enter the date (mm/dd/yy): ");
			String date = input.nextLine();
			

			
			
			
//			int getPlaces = makePlaces(input,"Please enter the places (1. Edmonds 2. Pier 55 3. Redondo Beach "
//					+ "4. Dash Point 5. Point Defiance 6. Waterman): ",6);
			

			
//Validate Places
			
			System.out.print("Please enter the places (1. Edmonds 2. Pier 55 3. Redondo Beach 4. Dash Point "
					+ "5. Point Defiance 6. Waterman): ");
			
			boolean isValidNumber;
			boolean error = false;
			int place;
			
		
			
			
			do {
				
				if(!input.hasNextInt()) {
					error = true;
					System.out.println("Please enter a number from 1 to 6 that indicates your places in the list.");
					
					System.out.print("Please enter the places (1. Edmonds 2. Pier 55 3. Redondo Beach 4. Dash Point "
							+ "5. Point Defiance 6. Waterman): ");
					input.nextLine();
				}
				
				place = input.nextInt();
				if (place >= 1 && place <= 6) {
					isValidNumber = true;
				//input.nextLine();
				}
				else {
					System.out.println("Please enter a number from 1 to 6 that indicates your places in the list.");
					isValidNumber = false;
					System.out.print("Please enter the places (1. Edmonds 2. Pier 55 3. Redondo Beach 4. Dash Point "
							+ "5. Point Defiance 6. Waterman): ");
					input.nextLine();
				}
//				else {
//					System.out.println("Please enter an integer!");
//				}
				
			} while (!(isValidNumber));
			
			
//Validate lbs of Squid	
			
			System.out.print("Please enter lbs of squid caught: ");
			//String pound = input.nextLine();
			double number = 0.0;
			do {
				if (input.hasNextDouble()) {
					number = input.nextDouble();
					isNumber = true;
				}
				else {
					System.out.println("That was not a valid number! Please try again.");
					isNumber = false;
					System.out.print("Please enter number of squid (lbs) caught: ");
					input.next();
				}
			} while (!(isNumber));
			
			
			
			System.out.println("[Your record] [Date] " + date + " --- [Place] " + arrayPlaces[place - 1] + " --- " + number + "lbs");
			System.out.print("Please confirm your record (Y/N): ");
			String yesNo = input.next();


			if (yesNo.toUpperCase().equals("Y")) {
				System.out.println("                                           THANK YOU FOR YOUR RECORD!");
				
				// Create Array
				String strNumber = String.valueOf(number);
				String[] a = { date, arrayPlaces[place - 1], strNumber};
				
				//Check the user input
				//System.out.println(a[0] + a[1] + a[2]);
				
				
				
				done = true; // Now we are done
				
			} else {
				System.out.println("                                            YOUR RECORD DID NOT SAVE!");
				// while no record, return to top of method (new input)

				if (yesNo.toUpperCase().equals("N")) {
					System.out.println("                                              RETURNING TO BEGINNING");
				input.nextLine();
					continue;
				}
			}
		}
		}
	

}
