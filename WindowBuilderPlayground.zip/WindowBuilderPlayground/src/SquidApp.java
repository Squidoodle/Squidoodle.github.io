import javax.swing.JApplet;
import javax.swing.JDesktopPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JSplitPane;
import javax.swing.JInternalFrame;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.DropMode;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import java.awt.Canvas;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class SquidApp extends JApplet {
	private JTextField textField;
	private JTextField textField_1;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Create the applet.
	 */
	public SquidApp() {
		
		JInternalFrame Map = new JInternalFrame("New JInternalFrame");
		Map.setBorder(new LineBorder(new Color(0, 0, 0)));
		Map.setClosable(true);
		Map.setVisible(true);
		
		JInternalFrame Data = new JInternalFrame("New JInternalFrame");
		Data.setResizable(true);
		Data.setBorder(new LineBorder(new Color(0, 0, 0)));
		Data.setClosable(true);
		Data.setVisible(true);
		
		JInternalFrame Log = new JInternalFrame("New JInternalFrame");
		Log.setBorder(new LineBorder(new Color(0, 0, 0)));
		Log.setClosable(true);
		Log.setVisible(true);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(Data, Alignment.LEADING)
						.addComponent(Map, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(Log, GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(Log, Alignment.LEADING)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addComponent(Map, GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(Data, GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)))
					.addGap(21))
		);
		
		JLabel lblLog = new JLabel("Log:");
		
		JTextPane textPane = new JTextPane();
		textPane.setEditable(false);
		textPane.setBackground(new Color(255, 153, 204));
		GroupLayout groupLayout_3 = new GroupLayout(Log.getContentPane());
		groupLayout_3.setHorizontalGroup(
			groupLayout_3.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout_3.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout_3.createParallelGroup(Alignment.LEADING)
						.addComponent(textPane, GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
						.addComponent(lblLog))
					.addContainerGap())
		);
		groupLayout_3.setVerticalGroup(
			groupLayout_3.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout_3.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblLog)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textPane, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
					.addContainerGap())
		);
		Log.getContentPane().setLayout(groupLayout_3);
		
		JLabel lblData = new JLabel("Data:");
		lblData.setFont(new Font("Lucida Grande", Font.BOLD, 17));
		
		JLabel lblName = new JLabel("Name: ");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel lblLbsOfSquid = new JLabel("Lbs Of Squid Caught:");
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		JLabel lblWhichPier = new JLabel("Which Pier:");
		
		JLabel lblCommentsieFishing = new JLabel("Comments: (i.e fishing techniques etc..");
		
		JButton btnSubmit = new JButton("Submit");
		
		JRadioButton rbEdmonds = new JRadioButton("Edmonds Pier");
		buttonGroup.add(rbEdmonds);
		
		JRadioButton rb55 = new JRadioButton("Pier 55");
		buttonGroup.add(rb55);
		
		JRadioButton rbRedondo = new JRadioButton("Redondo Beach Pier");
		buttonGroup.add(rbRedondo);
		
		JRadioButton rbDash = new JRadioButton("Dash Point");
		buttonGroup.add(rbDash);
		
		JRadioButton rbPointDefiance = new JRadioButton("Point Defiance");
		buttonGroup.add(rbPointDefiance);
		
		JRadioButton rbWatermanPier = new JRadioButton("Waterman Pier");
		buttonGroup.add(rbWatermanPier);
		GroupLayout groupLayout_2 = new GroupLayout(Data.getContentPane());
		groupLayout_2.setHorizontalGroup(
			groupLayout_2.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout_2.createSequentialGroup()
					.addContainerGap(664, Short.MAX_VALUE)
					.addComponent(btnSubmit)
					.addGap(17))
				.addGroup(Alignment.LEADING, groupLayout_2.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout_2.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout_2.createSequentialGroup()
							.addGap(6)
							.addComponent(rbPointDefiance)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rbWatermanPier))
						.addComponent(lblData)
						.addGroup(groupLayout_2.createSequentialGroup()
							.addComponent(lblName)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout_2.createSequentialGroup()
							.addComponent(lblLbsOfSquid)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout_2.createSequentialGroup()
							.addComponent(lblWhichPier)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout_2.createParallelGroup(Alignment.LEADING)
								.addComponent(lblCommentsieFishing)
								.addGroup(groupLayout_2.createSequentialGroup()
									.addComponent(rbEdmonds)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(rb55)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(rbRedondo)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(rbDash)))))
					.addContainerGap(223, Short.MAX_VALUE))
		);
		groupLayout_2.setVerticalGroup(
			groupLayout_2.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout_2.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblData)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblName)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLbsOfSquid)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblWhichPier)
						.addComponent(rbEdmonds)
						.addComponent(rb55)
						.addComponent(rbRedondo)
						.addComponent(rbDash))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(rbPointDefiance)
						.addComponent(rbWatermanPier))
					.addGap(46)
					.addComponent(lblCommentsieFishing)
					.addGap(113)
					.addComponent(btnSubmit)
					.addContainerGap(114, Short.MAX_VALUE))
		);
		Data.getContentPane().setLayout(groupLayout_2);
		
		JPanel panel = new JPanel();
		GroupLayout groupLayout_1 = new GroupLayout(Map.getContentPane());
		groupLayout_1.setHorizontalGroup(
			groupLayout_1.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, groupLayout_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout_1.setVerticalGroup(
			groupLayout_1.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, groupLayout_1.createSequentialGroup()
					.addGap(29)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(SquidApp.class.getResource("/resources/SquidMapKey.jpg")));
		lblNewLabel.setBounds(6, 6, 752, 500);
		panel.add(lblNewLabel);
		Map.getContentPane().setLayout(groupLayout_1);
		getContentPane().setLayout(groupLayout);

	
	}
}
