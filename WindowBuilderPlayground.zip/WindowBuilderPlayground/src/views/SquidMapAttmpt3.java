package views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import java.awt.TextField;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.UIManager;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class SquidMapAttmpt3 extends JFrame {

	private JPanel contentPane;
	private JTextField txtfldname;
	private JButton btnConfirmbutton;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JRadioButton rbYes;
	private JRadioButton rbNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SquidMapAttmpt3 frame = new SquidMapAttmpt3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SquidMapAttmpt3() {

		
		initComponents();
		createEvents();
	}
private void initComponents() {
//THIS METHOD INITIALIZED COMPONENTS
	setIconImage(Toolkit.getDefaultToolkit().getImage(SquidMapAttmpt3.class.getResource("/resources/tentacles_80.png")));
	setBackground(Color.BLACK);
	setTitle("SQUID MAP");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setBounds(100, 100, 450, 300);
	contentPane = new JPanel();
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(contentPane);
	
	JLabel lblName = new JLabel("Name:");
	
	txtfldname = new JTextField();

	txtfldname.setColumns(10);
	
	btnConfirmbutton = new JButton("confirmbutton");
	
	rbYes = new JRadioButton("Yes");
	rbYes.setSelected(true);
	buttonGroup.add(rbYes);
	
	rbNo = new JRadioButton("No");
	buttonGroup.add(rbNo);

	GroupLayout gl_contentPane = new GroupLayout(contentPane);
	gl_contentPane.setHorizontalGroup(
		gl_contentPane.createParallelGroup(Alignment.LEADING)
			.addGroup(gl_contentPane.createSequentialGroup()
				.addContainerGap()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addComponent(lblName)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(txtfldname, GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
						.addContainerGap())
					.addComponent(btnConfirmbutton, Alignment.TRAILING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addComponent(rbYes)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(rbNo)
						.addContainerGap(233, Short.MAX_VALUE))))
	);
	gl_contentPane.setVerticalGroup(
		gl_contentPane.createParallelGroup(Alignment.LEADING)
			.addGroup(gl_contentPane.createSequentialGroup()
				.addContainerGap()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
					.addComponent(lblName)
					.addComponent(txtfldname, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
					.addComponent(rbYes)
					.addComponent(rbNo))
				.addPreferredGap(ComponentPlacement.RELATED, 172, Short.MAX_VALUE)
				.addComponent(btnConfirmbutton)
				.addContainerGap())
	);
	contentPane.setLayout(gl_contentPane);
	}
	private void createEvents() {
/// THIS METHOD CONTAINS CODE FOR CREATING EVENTS	
	
		btnConfirmbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, txtfldname.getText());
				txtfldname.setText(txtfldname.getText() + " Stokes");
			}
		});
	}
}
